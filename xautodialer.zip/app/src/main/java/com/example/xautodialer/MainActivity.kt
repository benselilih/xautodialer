package com.example.xautodialer

import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val requestCallPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(this, "Phone call permission is required!", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent?.getBooleanExtra("TRIGGER_CALL", false) == true) {
            makePhoneCall()
        }

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AutoDialerScreen()
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("TRIGGER_CALL", false)) {
            makePhoneCall()
        }
    }

    private fun makePhoneCall() {
        val prefs = getSharedPreferences("xautodialer_prefs", Context.MODE_PRIVATE)
        val phone = prefs.getString("phone", "") ?: ""
        if (phone.isNotBlank() && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CALL_PHONE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phone"))
            startActivity(callIntent)
        }
    }

    @Composable
    fun AutoDialerScreen() {
        val context = LocalContext.current
        val prefs = remember { context.getSharedPreferences("xautodialer_prefs", Context.MODE_PRIVATE) }

        var phoneNumber by remember { mutableStateOf(prefs.getString("phone", "") ?: "") }
        var hour by remember { mutableIntStateOf(prefs.getInt("hour", 8)) }
        var minute by remember { mutableIntStateOf(prefs.getInt("minute", 0)) }
        var isEnabled by remember { mutableStateOf(prefs.getBoolean("enabled", false)) }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "xautodialer",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(32.dp))

            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { phoneNumber = it },
                label = { Text("Phone Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            val formattedTime = String.format("%02d:%02d", hour, minute)
            OutlinedButton(
                onClick = {
                    TimePickerDialog(
                        context,
                        { _, selectedHour, selectedMinute ->
                            hour = selectedHour
                            minute = selectedMinute
                        },
                        hour,
                        minute,
                        true
                    ).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "Select Time: $formattedTime", fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (phoneNumber.isBlank()) {
                        Toast.makeText(context, "Enter a phone number first", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    if (ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.CALL_PHONE
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        requestCallPermission.launch(Manifest.permission.CALL_PHONE)
                        return@Button
                    }

                    if (!Settings.canDrawOverlays(context)) {
                        Toast.makeText(
                            context,
                            "Please enable 'Display over other apps' for xautodialer",
                            Toast.LENGTH_LONG
                        ).show()
                        val overlayIntent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(overlayIntent)
                        return@Button
                    }

                    prefs.edit()
                        .putString("phone", phoneNumber)
                        .putInt("hour", hour)
                        .putInt("minute", minute)
                        .putBoolean("enabled", true)
                        .apply()

                    isEnabled = true
                    CallReceiver.scheduleNextAlarm(context, hour, minute)
                    Toast.makeText(context, "Scheduled daily call at $formattedTime", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save & Start Daily Schedule")
            }

            if (isEnabled) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = {
                        prefs.edit().putBoolean("enabled", false).apply()
                        isEnabled = false
                        CallReceiver.cancelAlarm(context)
                        Toast.makeText(context, "Schedule stopped", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Stop Schedule")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = if (isEnabled) "Active: Calling $phoneNumber daily at $formattedTime" else "Status: Inactive",
                color = if (isEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
