# xautodialer

Simple Android app that automatically dials a saved phone number at a scheduled time every day.

## How to Build in GitHub Cloud
1. Extract this ZIP archive.
2. Upload all extracted files and folders (including the `.github` folder) to your GitHub repository.
3. Open the **Actions** tab in your GitHub repository to watch the APK build automatically.
4. Once complete, download `xautodialer-apk` from the **Artifacts** section.
